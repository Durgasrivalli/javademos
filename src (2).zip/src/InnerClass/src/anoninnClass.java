
abstract public class anoninnClass {
	 public abstract void display();
		}


		
