package pac2;
import pac1.*;

public class accSpec4 {
public static void main(String[] args) {
		
		pubaccspec obj = new pubaccspec(); 
        obj.display();  
		
}
}
