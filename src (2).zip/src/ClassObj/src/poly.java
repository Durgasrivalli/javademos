class poly 
{
    public int sum(int x, int y) 
    { 
        return (x + y); 
    } 
    public int sum(int x, int y, int z) 
    { 
        return (x + y + z); 
    } 
    public double sum(double x, double y) 
    { 
        return (x + y); 
    } 
    public static void main(String args[]) 
    { 
        poly s = new poly(); 
        System.out.println(s.sum(11, 22)); 
        System.out.println(s.sum(13, 24, 35)); 
        System.out.println(s.sum(12.6, 65.8)); 
    } 
}
