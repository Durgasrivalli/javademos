
public class tstencapsule
{     
    public static void main (String[] args)  
    { 
        encapsule obj = new encapsule(); 
        obj.setName("Valli"); 
        obj.setAge(12); 
        obj.setRoll(1202); 
        System.out.println("My name: " + obj.getName()); 
        System.out.println("My age: " + obj.getAge()); 
        System.out.println("My roll: " + obj.getRoll());      
    } 
}
