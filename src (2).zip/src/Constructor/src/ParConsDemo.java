public class ParConsDemo {
	
		public static void main(String[] args) {

			Std std1=new Std(2,"Srivalli");
			Std std2=new Std(10,"Deva");
			std1.display();
			std2.display();
				}
}



