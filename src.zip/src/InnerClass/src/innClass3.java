public class innClass3 {

		public static void main(String[] args) {
			anoninnClass i = new anoninnClass() {

		         public void display() {
		            System.out.println("Anonymous Inner Class");
		         }
		      };
		      i.display();
		   }
}



