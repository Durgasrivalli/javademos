public class ConsDemo {
	public static void main(String[] args) {

		EmployeeInf emp1=new EmployeeInf();
		EmployeeInf emp2=new EmployeeInf();

		emp1.display();
		emp2.display();
		}
}

