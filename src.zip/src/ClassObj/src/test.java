
public class test  
{ 
    public static void main(String args[])  
    { 
        MouBike mb = new MouBike(6, 120, 19); 
        System.out.println(mb.toString());
    } 
}
