
public class tstabs  
{ 
    public static void main(String[] args) 
    { 
        abs1 s1 = new abs2("white", 2.6); 
        abs1 s2 = new abs3("grey", 6, 9);
        System.out.println(s1.toString()); 
        System.out.println(s2.toString()); 
    } 
}
