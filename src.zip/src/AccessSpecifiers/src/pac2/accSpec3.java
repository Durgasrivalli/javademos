package pac2;
import pac1.*;

public class accSpec3 extends proaccspec{

	
	
		public static void main(String[] args) {
			accSpec3 obj = new accSpec3 ();   
		       obj.display();  
		}

	}

