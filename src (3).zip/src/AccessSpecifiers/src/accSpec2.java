public class accSpec2 {
	
		public static void main(String[] args) {
			//private
			System.out.println("Private Access Specifier");
			priaccspec  obj = new priaccspec(); 
	        //trying to access private method of another class 
	        //obj.display();

		}
	}


