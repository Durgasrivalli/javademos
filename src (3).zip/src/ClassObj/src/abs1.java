
abstract class abs1  
{ 
    String color; 
    abstract double area(); 
    public abstract String toString(); 
    public abs1(String color) 
    { 
        System.out.println("Shape constructor called"); 
        this.color = color; 
    } 
    public String getColor() 
    { 
        return color; 
    } 
} 
