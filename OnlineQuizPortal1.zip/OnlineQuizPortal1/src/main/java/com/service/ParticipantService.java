package com.service;
import java.util.Optional;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import com.bean.Participant;
import com.bean.Question;
import com.bean.UserQuiz;
import com.repository.ParticipantRepository;
import com.repository.QuestionRepository;
import com.repository.UserQuizRepository;
@Service
public class ParticipantService {
	@Autowired
	ParticipantRepository participantRepository;
	@Autowired
	UserQuizRepository userQuizRepository;
	@Autowired
	QuestionRepository questionRepository;
	public String participantSignUp(Participant participant) {
		Optional<Participant> op=participantRepository.findById(participant.getPid());
		if(op.isPresent()) {
			return "Participant id must be unique";
		}else {
			 participantRepository.save(participant);      //insert new records
			 return "Record stored successfully";
		}
	}
	public String participantSignIn(Participant participant) {
		Optional<Participant> op=participantRepository.findById(participant.getPid());
		if(op.isPresent()) {
			Participant l=op.get();
			if(l.getEmailid().equals(participant.getEmailid())&&l.getPassword().equals(participant.getPassword())) {
				return "success";
			}
			else {
			 //update existing records
			return "failure";
			}
		}else {
			return "record not present";
		}
	}
	public String takeQuiz(UserQuiz userQuiz) {
		Optional<UserQuiz> op=	userQuizRepository.findById(userQuiz.getUqid());
		if(op.isPresent()) {
			return "User Quiz ID must be Unique";
		}
		else {
			userQuizRepository.save(userQuiz);
			return "Record Stored Successfully";
		}
		}
	}
