package com.service;
import java.util.List;
import java.util.Optional;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import com.bean.Login;
import com.bean.Participant;
import com.bean.Question;
import com.bean.Quiz;
import com.bean.UserQuiz;
import com.repository.LoginRepository;
import com.repository.ParticipantRepository;
import com.repository.QuestionRepository;
import com.repository.QuizRepository;
import com.repository.UserQuizRepository;
@Service
public class LoginService {
	@Autowired
	LoginRepository loginRepository;
	@Autowired
	QuestionRepository questionRepository;
	@Autowired
	QuizRepository quizRepository;
	@Autowired
	ParticipantRepository participantRepository;
	@Autowired
	UserQuizRepository userQuizRepository;

	public String findAdmin(String emailid) {
		Optional<Login> op=loginRepository.findById(emailid);
		if(op.isPresent()) {
			//Login l=op.get();
			return "success";
		}else {
			return "failure";
		}
   }
	public String changePassword(Login login) {
		Optional<Login> op=loginRepository.findById(login.getEmailid());
		if(op.isPresent()) {
			Login l=op.get();
			if(l.getPassword().equals(login.getPassword())) {
				return "record updation failure";
			}
			else {
			l.setPassword(login.getPassword());
			loginRepository.saveAndFlush(l);    //update existing records
			return "Record updated successfully";
			}
		}else {
			 //employeeRepository.save(emp);
			 return "Record not present";
		}
	}
	public String addQuestiion(Question question) {
		Optional<Question> op=questionRepository.findById(question.getQid());
		if(op.isPresent()) {
			return "Question id must be unique";
		}else {
			 questionRepository.save(question);      //insert new records
			 return "Record stored successfully";
		}
	}
	public String findQuestion(int qid) {
		Optional<Question> op=questionRepository.findById(qid);
		if(op.isPresent()) {
			Question q=op.get();
			return q.toString();
		}else {
			return "Record not present";
		}
   }
	public String createQuiz(Quiz quiz) {
		Optional<Quiz> op=quizRepository.findById(quiz.getQzid());
		if(op.isPresent()) {
			return "Quiz id must be unique";
		}else {
			 quizRepository.save(quiz);      //insert new records
			 return "Record stored successfully";
		}
	}
	public List<Participant> getAllParticipants(){
		return participantRepository.findAll();
		
	}
	public List<Question> getAllQuestions(){
		return questionRepository.findAll();
		}
	public List<Quiz> getAllQuiz(){
		return quizRepository.findAll();
		}
	public List<UserQuiz> getAllUserQuiz(){
		return userQuizRepository.findAll();
		}
}
