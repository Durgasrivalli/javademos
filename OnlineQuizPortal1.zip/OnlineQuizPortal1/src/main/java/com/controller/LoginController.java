package com.controller;
import java.util.List;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.MediaType;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import com.bean.Login;
import com.bean.Participant;
import com.bean.Question;
import com.bean.Quiz;
import com.bean.UserQuiz;
import com.service.LoginService;
@RestController
@RequestMapping("admin")
public class LoginController {
	@Autowired
	LoginService loginService;
	//localhost:8080/admin/adminSignIn
	@GetMapping(value="adminSignIn/{emailid}")
	public String adminSignIn(@PathVariable("emailid") String emailid) {
		return loginService.findAdmin(emailid);
	}
	//localhost:8080/admin/changePassword
	@PutMapping(value="changePassword",consumes=MediaType.APPLICATION_JSON_VALUE)
	public String changePassword(@RequestBody Login login) {
		return loginService.changePassword(login);
	}
	//localhost:8080/admin/addQuestion
	@PostMapping(value="addQuestion",consumes=MediaType.APPLICATION_JSON_VALUE)
	public String addQuestion(@RequestBody Question question)
	{
		return loginService.addQuestiion(question);
	}
	//localhost:8080/admin/findQuestion/1
		@GetMapping(value="findQuestion/{qid}")
		public String findQuestion(@PathVariable("qid") int qid) {
			return loginService.findQuestion(qid);
		}
		//localhost:8080/admin/createQuiz
		@PostMapping(value="createQuiz",consumes=MediaType.APPLICATION_JSON_VALUE)
		public String createQuiz(@RequestBody Quiz quiz)
		{
			return loginService.createQuiz(quiz);
		}
		//localhost:8080/admin/findAllParticipant
		@GetMapping(value="findAllParticipant",produces=MediaType.APPLICATION_JSON_VALUE)
		public List<Participant> getAllParticipant(){
			return loginService.getAllParticipants();
		}
		@GetMapping(value="getAllQuestions",produces=MediaType.APPLICATION_JSON_VALUE)
		public List<Question> getAllQuestions(){
			return loginService.getAllQuestions();
		}
		@GetMapping(value="getAllQuiz",produces=MediaType.APPLICATION_JSON_VALUE)
		public List<Quiz> getAllQuiz(){
			return loginService.getAllQuiz();
		}
		@GetMapping(value="getAllUserQuiz",produces=MediaType.APPLICATION_JSON_VALUE)
		public List<UserQuiz> getAllUserQuiz(){
			return loginService.getAllUserQuiz();
		}
}
