package com.controller;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.MediaType;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import com.bean.Participant;
import com.bean.UserQuiz;
import com.service.ParticipantService;
@RestController
@RequestMapping("participant")
public class ParticipantController {
	@Autowired
	ParticipantService participantService;
	//localhost:8080/admin/participantSignUp
		@PostMapping(value="participantSignUp",consumes=MediaType.APPLICATION_JSON_VALUE)
		public String participantSignUp(@RequestBody Participant participant)
		{
			return participantService.participantSignUp(participant);
		}
		//localhost:8080/admin/participantSignIn
		@PutMapping(value="participantSignIn",consumes=MediaType.APPLICATION_JSON_VALUE)
		public String participantSignIn(@RequestBody Participant participant) {
			return participantService.participantSignIn(participant);
		}
		@PostMapping(value="takeQuiz",consumes=MediaType.APPLICATION_JSON_VALUE)
		public String takeQuiz(@RequestBody UserQuiz userQuiz)
		{
			return participantService.takeQuiz(userQuiz);
		}
}
