package com.bean;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.ManyToOne;
import javax.persistence.OneToMany;
import javax.persistence.OneToOne;
import javax.persistence.Table;
import org.springframework.beans.factory.annotation.Autowired;
@Entity
@Table(name="quiz")
public class Quiz {
	@Id
	private int qzid;
	private String title;
	private String subject;
	private Integer qid;
	public int getQzid() {
		return qzid;
	}
	public void setQzid(int qzid) {
		this.qzid = qzid;
	}
	public String getTitle() {
		return title;
	}
	public void setTitle(String title) {
		this.title = title;
	}
	public String getSubject() {
		return subject;
	}
	public void setSubject(String subject) {
		this.subject = subject;
	}
	public Integer getQid() {
		return qid;
	}
	public void setQid(Integer qid) {
		this.qid = qid;
	}
	@Override
	public String toString() {
		return "Quiz [qzid=" + qzid + ", title=" + title + ", subject=" + subject + ", qid=" + qid + "]";
	}
}
