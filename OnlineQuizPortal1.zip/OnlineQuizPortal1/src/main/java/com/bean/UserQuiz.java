package com.bean;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;
@Entity
@Table(name="userquiz")
public class UserQuiz {
	@Id
	private int uqid;
	private String emailid;
	private Integer qzid;
	private Integer qid;
	private String useranswer;
	public int getUqid() {
		return uqid;
	}
	public void setUqid(int uqid) {
		this.uqid = uqid;
	}
	public String getEmailid() {
		return emailid;
	}
	public void setEmailid(String emailid) {
		this.emailid = emailid;
	}
	public Integer getQzid() {
		return qzid;
	}
	public void setQzid(Integer qzid) {
		this.qzid = qzid;
	}
	public Integer getQid() {
		return qid;
	}
	public void setQid(Integer qid) {
		this.qid = qid;
	}
	public String getUseranswer() {
		return useranswer;
	}
	public void setUseranswer(String useranswer) {
		this.useranswer = useranswer;
	}
	@Override
	public String toString() {
		return "UserQuiz [uqid=" + uqid + ", emailid=" + emailid + ", qzid=" + qzid + ", qid=" + qid + ", useranswer="
				+ useranswer + "]";
	}
	
}
